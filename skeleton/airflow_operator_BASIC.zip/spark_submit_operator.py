import airflow

from airflow.models import DAG
from airflow.contrib.operator.spark_submit_operator import SparkSubmitOperator
from airflow.utils.dates import days_ago

dag_conf = DAG(
    dag_id="sparkSubmitOperatorDemo",
    schedule_interval="* * * * *",
    start_date=days_ago(1)
)

_configdetails = {}

spark_submit_local = SparkSubmitOperator(
    task_id="sparksubmitjobs",
    application = "<py file full path>",
    conn_id = "<created connection id by spark>",
    dag=dag_conf)
    
spark_submit_local    

if __main__ == "__main__"    :
    dag_conf.cli()