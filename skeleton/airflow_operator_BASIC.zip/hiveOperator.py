from airflow

from airflow.models import DAG
from airflow.operators.hive_operator import HiveOperator
from airflow.utils.dates import days_ago
dag_hive = DAG(dag_id='hiveOperator',
               schedule_interval='* * * * *',
               start_date=days_ago(1))
               
hql_query = """use training;
create table if not exists airflow_hive (id int, name string);
insert into airflow_hive values(1,"bigdata");"""

hive_task = HiveOperator(task_id='hive_script_task',
                         hql=hql_query,
                         hive_cli_conn_id='hive_local',
                         dag=dag_hive)

hive_task

if __name__ == "__main__":
  dag_hive.cli()