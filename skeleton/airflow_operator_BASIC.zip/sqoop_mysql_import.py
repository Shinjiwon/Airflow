import airflow

from airflow.models import DAG
from airflow.contrib.operators.sqoop_operator import SqoopOperator
from airflow.utils.dates import days_ago

Dag_Sqoop_Import = DAG(dag_id="SqoopImport",
					   schdule_interfal="* * * * *",
					   start_date=days_ago(2))
					   
sqoop_mysql_import = SqoopOperator(task_id="sqoop_import",
								   conn_id="sqoop_local"
								   table="weblogtest",
								   cmd_type="import",
								   target_dir="/airflow+sqoopImport",
								   num_mappers=1,
								   dag=Dag_Sqoop_Import)

sqoop_mysql_import

if __main__ == "__main__"    :
    Dag_Sqoop_Import.cli()								   